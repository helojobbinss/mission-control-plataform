import { useAuthStore } from '@/stores/auth-store'

const roleLabels: Record<string, string> = {
  gerente: 'Gerente',
  operador: 'Operador',
  analista_dados: 'Analista de dados',
}

export function roleLabel(role: string | null | undefined) {
  if (!role) return 'Sem papel'
  return roleLabels[role] ?? role
}

/** Dados do usuário logado prontos para exibir (nome, e-mail, iniciais, papel). */
export function useCurrentUser() {
  const user = useAuthStore((s) => s.auth.user)
  const name = user?.name ?? 'Usuário'
  const initials =
    name
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((part) => part[0]?.toUpperCase())
      .join('') || 'U'

  return {
    user,
    name,
    email: user?.email ?? '',
    initials,
    role: roleLabel(user?.role),
  }
}
