import { AxiosError, type AxiosResponse } from 'axios'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { render } from 'vitest-browser-react'
import { userEvent } from 'vitest/browser'
import { login } from '@/features/auth/api'
import { UserAuthForm } from './user-auth-form'

const navigate = vi.fn()
const setUserMock = vi.fn()
const setAccessTokenMock = vi.fn()

vi.mock('@/features/auth/api', () => ({ login: vi.fn() }))

vi.mock('@/stores/auth-store', () => ({
  useAuthStore: () => ({
    auth: {
      setUser: setUserMock,
      setAccessToken: setAccessTokenMock,
    },
  }),
}))

vi.mock('@tanstack/react-router', async (importOriginal) => {
  const actual = await importOriginal<typeof import('@tanstack/react-router')>()
  return {
    ...actual,
    useNavigate: () => navigate,
    Link: ({
      children,
      to,
      className,
      ...rest
    }: {
      children?: React.ReactNode
      to: string
      className?: string
    }) => (
      <a href={to} className={className} {...rest}>
        {children}
      </a>
    ),
  }
})

const USER = {
  id: 1,
  name: 'Administrador',
  email: 'admin@missioncontrol.local',
  role: 'gerente',
}

async function fillAndSubmit(
  screen: Awaited<ReturnType<typeof render>>,
  email = USER.email,
  password = 'Admin@1234'
) {
  await userEvent.fill(screen.getByRole('textbox', { name: 'Email' }), email)
  await userEvent.fill(screen.getByLabelText('Senha'), password)
  await userEvent.click(screen.getByRole('button', { name: 'Login' }))
}

describe('UserAuthForm', () => {
  beforeEach(() => vi.clearAllMocks())

  it('mostra as mensagens de validação com o formulário vazio', async () => {
    const screen = await render(<UserAuthForm />)

    await userEvent.click(screen.getByRole('button', { name: 'Login' }))

    await expect
      .element(screen.getByText('Por favor insira seu email.'))
      .toBeInTheDocument()
    await expect
      .element(screen.getByText('Por favor insira sua senha.'))
      .toBeInTheDocument()
    expect(login).not.toHaveBeenCalled()
  })

  it('faz login na API, guarda token e usuário e vai para o painel', async () => {
    vi.mocked(login).mockResolvedValue({
      message: 'ok',
      token: '1|token-sanctum',
      token_type: 'Bearer',
      user: USER,
    })
    const screen = await render(<UserAuthForm />)

    await fillAndSubmit(screen)

    await vi.waitFor(() =>
      expect(login).toHaveBeenCalledWith(USER.email, 'Admin@1234')
    )
    expect(setAccessTokenMock).toHaveBeenCalledWith('1|token-sanctum')
    expect(setUserMock).toHaveBeenCalledWith(USER)
    await vi.waitFor(() =>
      expect(navigate).toHaveBeenCalledWith({ to: '/', replace: true })
    )
  })

  it('volta para a página pedida (redirectTo) depois do login', async () => {
    vi.mocked(login).mockResolvedValue({
      message: 'ok',
      token: 't',
      token_type: 'Bearer',
      user: USER,
    })
    const screen = await render(<UserAuthForm redirectTo='/monitoramento' />)

    await fillAndSubmit(screen)

    await vi.waitFor(() =>
      expect(navigate).toHaveBeenCalledWith({
        to: '/monitoramento',
        replace: true,
      })
    )
  })

  it('mostra o erro do backend quando a senha está errada (422)', async () => {
    const error = new AxiosError('Unprocessable')
    error.response = {
      status: 422,
      data: {
        message: 'The given data was invalid.',
        errors: { email: ['E-mail ou senha inválidos.'] },
      },
    } as AxiosResponse
    vi.mocked(login).mockRejectedValue(error)
    const screen = await render(<UserAuthForm />)

    await fillAndSubmit(screen, USER.email, 'errada')

    await expect
      .element(screen.getByText('E-mail ou senha inválidos.'))
      .toBeInTheDocument()
    expect(setAccessTokenMock).not.toHaveBeenCalled()
    expect(navigate).not.toHaveBeenCalled()
  })
})
