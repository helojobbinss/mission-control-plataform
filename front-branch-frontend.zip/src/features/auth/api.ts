import axios from 'axios'
import { type AuthUser } from '@/stores/auth-store'

/** Chamadas de autenticação do backend (AuthController). */

type LoginResponse = {
  message: string
  token: string
  token_type: 'Bearer'
  user: AuthUser
}

export async function login(email: string, password: string) {
  const { data } = await axios.post<LoginResponse>('/api/login', {
    email,
    password,
  })
  return data
}

export async function fetchCurrentUser() {
  const { data } = await axios.get<{ user: AuthUser }>('/api/user')
  return data.user
}

export async function logout() {
  await axios.post('/api/logout')
}
