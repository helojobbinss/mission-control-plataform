import { z } from 'zod'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import { apiErrorMessage, apiFieldErrors } from '@/lib/api'
import { roleLabel } from '@/hooks/use-current-user'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import { Input } from '@/components/ui/input'
import { PasswordInput } from '@/components/password-input'
import { SelectDropdown } from '@/components/select-dropdown'
import { createUser, listRoles } from '../data/api'
import { type User } from '../data/schema'

const formSchema = z
  .object({
    name: z.string().trim().min(1, 'Nome é obrigatório.'),
    email: z.email({
      error: (iss) =>
        iss.input === '' ? 'E-mail é obrigatório.' : 'E-mail inválido.',
    }),
    role: z.string().min(1, 'Selecione um papel.'),
    password: z
      .string()
      .min(8, 'A senha precisa ter pelo menos 8 caracteres.')
      .regex(/[a-zA-Z]/, 'A senha precisa ter pelo menos uma letra.')
      .regex(/\d/, 'A senha precisa ter pelo menos um número.'),
    confirmPassword: z.string(),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: 'As senhas não coincidem.',
    path: ['confirmPassword'],
  })
type UserForm = z.infer<typeof formSchema>

/** Campos do backend -> campos do formulário, para mostrar erros 422. */
const fieldMap: Record<string, keyof UserForm> = {
  name: 'name',
  email: 'email',
  password: 'password',
  role_id: 'role',
}

type UserActionDialogProps = {
  /** Edição ainda não existe na API; mantido para compatibilidade. */
  currentRow?: User
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function UsersActionDialog({
  open,
  onOpenChange,
}: UserActionDialogProps) {
  const queryClient = useQueryClient()
  const form = useForm<UserForm>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      email: '',
      role: '',
      password: '',
      confirmPassword: '',
    },
  })

  const rolesQuery = useQuery({
    queryKey: ['roles'],
    queryFn: listRoles,
    enabled: open,
    staleTime: 5 * 60 * 1000,
  })

  const mutation = useMutation({
    mutationFn: (values: UserForm) =>
      createUser({
        name: values.name,
        email: values.email,
        password: values.password,
        password_confirmation: values.confirmPassword,
        role_id: Number(values.role),
      }),
    // Erros tratados aqui (não usa o toast genérico do QueryClient)
    onError: (error) => {
      const fields = apiFieldErrors(error)
      let mapped = false
      for (const [apiField, message] of Object.entries(fields)) {
        const formField = fieldMap[apiField]
        if (formField) {
          form.setError(formField, { message })
          mapped = true
        }
      }
      if (!mapped) toast.error(apiErrorMessage(error))
    },
    onSuccess: (user) => {
      toast.success(`Usuário ${user.name} criado.`)
      queryClient.invalidateQueries({ queryKey: ['users'] })
      form.reset()
      onOpenChange(false)
    },
  })

  const isPasswordTouched = !!form.formState.dirtyFields.password

  return (
    <Dialog
      open={open}
      onOpenChange={(state) => {
        if (mutation.isPending) return
        form.reset()
        onOpenChange(state)
      }}
    >
      <DialogContent className='sm:max-w-lg'>
        <DialogHeader className='text-start'>
          <DialogTitle>Novo usuário</DialogTitle>
          <DialogDescription>
            Preencha os dados e clique em salvar. O usuário poderá entrar com
            este e-mail e senha.
          </DialogDescription>
        </DialogHeader>
        <div className='w-[calc(100%+0.75rem)] overflow-y-auto py-1 pe-3'>
          <Form {...form}>
            <form
              id='user-form'
              onSubmit={form.handleSubmit((values) => mutation.mutate(values))}
              className='space-y-4 px-0.5'
            >
              <FormField
                control={form.control}
                name='name'
                render={({ field }) => (
                  <FormItem className='grid grid-cols-6 items-center space-y-0 gap-x-4 gap-y-1'>
                    <FormLabel className='col-span-2 text-end'>Nome</FormLabel>
                    <FormControl>
                      <Input
                        placeholder='Maria Silva'
                        className='col-span-4'
                        autoComplete='off'
                        {...field}
                      />
                    </FormControl>
                    <FormMessage className='col-span-4 col-start-3' />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name='email'
                render={({ field }) => (
                  <FormItem className='grid grid-cols-6 items-center space-y-0 gap-x-4 gap-y-1'>
                    <FormLabel className='col-span-2 text-end'>
                      E-mail
                    </FormLabel>
                    <FormControl>
                      <Input
                        placeholder='maria@missioncontrol.local'
                        className='col-span-4'
                        autoComplete='off'
                        {...field}
                      />
                    </FormControl>
                    <FormMessage className='col-span-4 col-start-3' />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name='role'
                render={({ field }) => (
                  <FormItem className='grid grid-cols-6 items-center space-y-0 gap-x-4 gap-y-1'>
                    <FormLabel className='col-span-2 text-end'>Papel</FormLabel>
                    <SelectDropdown
                      defaultValue={field.value}
                      onValueChange={field.onChange}
                      isPending={rolesQuery.isLoading}
                      placeholder={
                        rolesQuery.isError
                          ? 'Erro ao carregar papéis'
                          : 'Selecione um papel'
                      }
                      className='col-span-4'
                      items={(rolesQuery.data ?? []).map((role) => ({
                        label: roleLabel(role.name),
                        value: String(role.id),
                      }))}
                    />
                    <FormMessage className='col-span-4 col-start-3' />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name='password'
                render={({ field }) => (
                  <FormItem className='grid grid-cols-6 items-center space-y-0 gap-x-4 gap-y-1'>
                    <FormLabel className='col-span-2 text-end'>Senha</FormLabel>
                    <FormControl>
                      <PasswordInput
                        placeholder='Mínimo 8 caracteres'
                        className='col-span-4'
                        autoComplete='new-password'
                        {...field}
                      />
                    </FormControl>
                    <FormMessage className='col-span-4 col-start-3' />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name='confirmPassword'
                render={({ field }) => (
                  <FormItem className='grid grid-cols-6 items-center space-y-0 gap-x-4 gap-y-1'>
                    <FormLabel className='col-span-2 text-end'>
                      Confirmar senha
                    </FormLabel>
                    <FormControl>
                      <PasswordInput
                        disabled={!isPasswordTouched}
                        placeholder='Repita a senha'
                        className='col-span-4'
                        autoComplete='new-password'
                        {...field}
                      />
                    </FormControl>
                    <FormMessage className='col-span-4 col-start-3' />
                  </FormItem>
                )}
              />
            </form>
          </Form>
        </div>
        <DialogFooter>
          <Button type='submit' form='user-form' disabled={mutation.isPending}>
            {mutation.isPending && <Loader2 className='animate-spin' />}
            Salvar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
