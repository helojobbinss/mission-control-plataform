import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { render } from 'vitest-browser-react'
import { userEvent } from 'vitest/browser'
import { createUser, listRoles } from '../data/api'
import { UsersActionDialog } from './users-action-dialog'

vi.mock('../data/api', () => ({
  listRoles: vi.fn(),
  createUser: vi.fn(),
}))

function renderDialog(onOpenChange = vi.fn()) {
  const client = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  })
  return render(
    <QueryClientProvider client={client}>
      <UsersActionDialog open onOpenChange={onOpenChange} />
    </QueryClientProvider>
  )
}

describe('UsersActionDialog', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    vi.mocked(listRoles).mockResolvedValue([
      { id: 1, name: 'gerente', description: null },
      { id: 2, name: 'operador', description: null },
    ])
  })

  it('mostra as mensagens de validação com o formulário vazio', async () => {
    const screen = await renderDialog()

    await userEvent.click(screen.getByRole('button', { name: 'Salvar' }))

    await expect
      .element(screen.getByText('Nome é obrigatório.'))
      .toBeInTheDocument()
    await expect
      .element(screen.getByText('E-mail é obrigatório.'))
      .toBeInTheDocument()
    await expect
      .element(screen.getByText('Selecione um papel.'))
      .toBeInTheDocument()
    expect(createUser).not.toHaveBeenCalled()
  })

  it('envia o cadastro para a API com o role_id do papel escolhido', async () => {
    vi.mocked(createUser).mockResolvedValue({
      id: '5',
      name: 'Maria',
      email: 'maria@missioncontrol.local',
      role: 'operador',
      status: 'ativo',
      createdAt: null,
    })
    const onOpenChange = vi.fn()
    const screen = await renderDialog(onOpenChange)

    await userEvent.fill(screen.getByLabelText('Nome'), 'Maria')
    await userEvent.fill(
      screen.getByLabelText('E-mail'),
      'maria@missioncontrol.local'
    )
    await userEvent.click(screen.getByRole('combobox'))
    await userEvent.click(screen.getByRole('option', { name: 'Operador' }))
    await userEvent.fill(
      screen.getByLabelText('Senha', { exact: true }),
      'Senha123'
    )
    await userEvent.fill(screen.getByLabelText('Confirmar senha'), 'Senha123')
    await userEvent.click(screen.getByRole('button', { name: 'Salvar' }))

    await expect.poll(() => vi.mocked(createUser).mock.calls.length).toBe(1)
    expect(vi.mocked(createUser).mock.calls[0][0]).toEqual({
      name: 'Maria',
      email: 'maria@missioncontrol.local',
      password: 'Senha123',
      password_confirmation: 'Senha123',
      role_id: 2,
    })
    await expect.poll(() => onOpenChange).toHaveBeenCalledWith(false)
  })
})
