import axios from 'axios'
import { type User } from './schema'

/** Chamadas de usuários do backend (UserController). */

type ApiUser = {
  id: number
  name: string
  email: string
  role: string | null
  is_active: boolean
  created_at: string | null
}

export type ApiRole = {
  id: number
  name: string
  description: string | null
}

export type NewUserInput = {
  name: string
  email: string
  password: string
  password_confirmation: string
  role_id: number
}

const toUser = (u: ApiUser): User => ({
  id: String(u.id),
  name: u.name,
  email: u.email,
  role: u.role,
  status: u.is_active ? 'ativo' : 'inativo',
  createdAt: u.created_at ? new Date(u.created_at) : null,
})

export async function listUsers(): Promise<User[]> {
  const { data } = await axios.get<{ users: ApiUser[] }>('/api/users')
  return data.users.map(toUser)
}

export async function listRoles(): Promise<ApiRole[]> {
  const { data } = await axios.get<{ roles: ApiRole[] }>('/api/roles')
  return data.roles
}

export async function createUser(input: NewUserInput): Promise<User> {
  const { data } = await axios.post<{ user: ApiUser }>('/api/users', input)
  return toUser(data.user)
}
