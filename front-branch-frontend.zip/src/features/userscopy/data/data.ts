import { BriefcaseBusiness, Headset, ScanSearch } from 'lucide-react'
import { type UserStatus } from './schema'

export const callTypes = new Map<UserStatus, string>([
  ['ativo', 'bg-teal-100/30 text-teal-900 dark:text-teal-200 border-teal-200'],
  ['inativo', 'bg-neutral-300/40 border-neutral-300'],
])

/** Papéis do backend (RoleSeeder) com rótulo e ícone para a tela. */
export const roles = [
  {
    label: 'Gerente',
    value: 'gerente',
    icon: BriefcaseBusiness,
  },
  {
    label: 'Operador',
    value: 'operador',
    icon: Headset,
  },
  {
    label: 'Analista de dados',
    value: 'analista_dados',
    icon: ScanSearch,
  },
] as const
