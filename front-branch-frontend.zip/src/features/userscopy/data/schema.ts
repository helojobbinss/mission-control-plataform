import { type RoleName } from '@/stores/auth-store'

export type UserStatus = 'ativo' | 'inativo'

/** Linha da tabela de usuários (convertida a partir da API). */
export type User = {
  id: string
  name: string
  email: string
  role: RoleName | string | null
  status: UserStatus
  createdAt: Date | null
}
