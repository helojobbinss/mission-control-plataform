import { useQuery } from '@tanstack/react-query'
import { getRouteApi } from '@tanstack/react-router'
import { ShieldAlert } from 'lucide-react'
import { isManager, useAuthStore } from '@/stores/auth-store'
import { apiErrorMessage } from '@/lib/api'
import { ConfigDrawer } from '@/components/config-drawer'
import { Header } from '@/components/layout/header'
import { Main } from '@/components/layout/main'
import { ProfileDropdown } from '@/components/profile-dropdown'
import { Search } from '@/components/search'
import { ThemeSwitch } from '@/components/theme-switch'
import { UsersDialogs } from './components/users-dialogs'
import { UsersPrimaryButtons } from './components/users-primary-buttons'
import { UsersProvider } from './components/users-provider'
import { UsersTable } from './components/users-table'
import { listUsers } from './data/api'

const route = getRouteApi('/_authenticated/userscopy/')

export function Users() {
  const search = route.useSearch()
  const navigate = route.useNavigate()
  const user = useAuthStore((s) => s.auth.user)
  const canManage = isManager(user)

  const usersQuery = useQuery({
    queryKey: ['users'],
    queryFn: listUsers,
    enabled: canManage,
  })

  const emptyMessage = usersQuery.isLoading
    ? 'Carregando usuários…'
    : usersQuery.isError
      ? apiErrorMessage(usersQuery.error, 'Erro ao carregar usuários.')
      : 'Nenhum usuário encontrado.'

  return (
    <UsersProvider>
      <Header fixed>
        <Search className='me-auto' />
        <ThemeSwitch />
        <ConfigDrawer />
        <ProfileDropdown />
      </Header>

      <Main className='flex flex-1 flex-col gap-4 sm:gap-6'>
        <div className='flex flex-wrap items-end justify-between gap-2'>
          <div>
            <h2 className='text-2xl font-bold tracking-tight'>
              Gestão e dados
            </h2>
            <p className='text-muted-foreground'>
              Gerencie os usuários e acessos
            </p>
          </div>
          {canManage && <UsersPrimaryButtons />}
        </div>

        {canManage ? (
          <UsersTable
            data={usersQuery.data ?? []}
            emptyMessage={emptyMessage}
            search={search}
            navigate={navigate}
          />
        ) : (
          <div className='flex flex-col items-center gap-2 rounded-md border border-dashed p-10 text-center'>
            <ShieldAlert className='size-8 text-muted-foreground' />
            <p className='font-medium'>Acesso restrito a gerentes</p>
            <p className='max-w-md text-sm text-muted-foreground'>
              Apenas usuários com papel de gerente podem ver e cadastrar
              usuários. Fale com um gerente se precisar de acesso.
            </p>
          </div>
        )}
      </Main>

      <UsersDialogs />
    </UsersProvider>
  )
}
