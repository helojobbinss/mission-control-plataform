import { create } from 'zustand'
import { getCookie, setCookie, removeCookie } from '@/lib/cookies'

const ACCESS_TOKEN = 'mc_access_token'

/** Papéis cadastrados no backend (RoleSeeder). */
export type RoleName = 'gerente' | 'operador' | 'analista_dados'

/** Usuário como o backend devolve em POST /api/login e GET /api/user. */
export interface AuthUser {
  id: number
  name: string
  email: string
  role: RoleName | string | null
  is_active?: boolean
}

interface AuthState {
  auth: {
    user: AuthUser | null
    setUser: (user: AuthUser | null) => void
    accessToken: string
    setAccessToken: (accessToken: string) => void
    resetAccessToken: () => void
    reset: () => void
  }
}

function readPersistedToken(): string {
  const cookieState = getCookie(ACCESS_TOKEN)
  if (!cookieState) return ''
  try {
    return JSON.parse(decodeURIComponent(cookieState))
  } catch {
    return ''
  }
}

export const useAuthStore = create<AuthState>()((set) => {
  const initToken = readPersistedToken()
  return {
    auth: {
      user: null,
      setUser: (user) =>
        set((state) => ({ ...state, auth: { ...state.auth, user } })),
      accessToken: initToken,
      setAccessToken: (accessToken) =>
        set((state) => {
          setCookie(
            ACCESS_TOKEN,
            encodeURIComponent(JSON.stringify(accessToken))
          )
          return { ...state, auth: { ...state.auth, accessToken } }
        }),
      resetAccessToken: () =>
        set((state) => {
          removeCookie(ACCESS_TOKEN)
          return { ...state, auth: { ...state.auth, accessToken: '' } }
        }),
      reset: () =>
        set((state) => {
          removeCookie(ACCESS_TOKEN)
          return {
            ...state,
            auth: { ...state.auth, user: null, accessToken: '' },
          }
        }),
    },
  }
})

/** Atalho: o usuário logado é gerente? */
export const isManager = (user: AuthUser | null) => user?.role === 'gerente'
