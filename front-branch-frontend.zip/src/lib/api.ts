import axios, { AxiosError } from 'axios'
import { useAuthStore } from '@/stores/auth-store'

/**
 * Configuração única do axios para falar com o backend Laravel.
 *
 * - Todas as chamadas usam caminhos relativos (/api/...). Em dev, o Vite
 *   repassa /api para http://127.0.0.1:8000 (ver vite.config.ts).
 * - O token do Sanctum (recebido no login) vai em todas as requisições
 *   como "Authorization: Bearer <token>".
 * - Um 401 em qualquer chamada (token expirado/revogado) dispara
 *   `onUnauthorized`, que limpa a sessão e manda para o login.
 */
let configured = false

export function setupApi(onUnauthorized: () => void) {
  if (configured) return
  configured = true

  axios.defaults.headers.common.Accept = 'application/json'

  axios.interceptors.request.use((config) => {
    const token = useAuthStore.getState().auth.accessToken
    if (token) config.headers.Authorization = `Bearer ${token}`
    return config
  })

  axios.interceptors.response.use(
    (response) => response,
    (error) => {
      const isLoginCall = error?.config?.url?.endsWith('/api/login')
      if (
        error instanceof AxiosError &&
        error.response?.status === 401 &&
        !isLoginCall
      ) {
        onUnauthorized()
      }
      return Promise.reject(error)
    }
  )
}

type LaravelErrorBody = {
  message?: string
  title?: string
  errors?: Record<string, string[]>
}

/** Erros de validação do Laravel (422) no formato { campo: mensagem }. */
export function apiFieldErrors(error: unknown): Record<string, string> {
  if (!(error instanceof AxiosError)) return {}
  const errors = (error.response?.data as LaravelErrorBody | undefined)?.errors
  if (!errors) return {}
  return Object.fromEntries(
    Object.entries(errors).map(([field, messages]) => [field, messages[0]])
  )
}

/** Mensagem legível para mostrar ao usuário a partir de um erro da API. */
export function apiErrorMessage(
  error: unknown,
  fallback = 'Não foi possível concluir a operação.'
): string {
  if (!(error instanceof AxiosError)) return fallback
  if (!error.response) {
    return 'Não foi possível conectar ao servidor. Verifique se o backend está rodando.'
  }
  const firstFieldError = Object.values(apiFieldErrors(error))[0]
  if (firstFieldError) return firstFieldError

  const body = error.response.data as LaravelErrorBody | undefined
  if (typeof body?.message === 'string' && body.message) return body.message
  if (typeof body?.title === 'string' && body.title) return body.title
  return fallback
}
