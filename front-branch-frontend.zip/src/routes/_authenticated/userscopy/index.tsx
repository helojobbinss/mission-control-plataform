import z from 'zod'
import { createFileRoute } from '@tanstack/react-router'
import { Users } from '@/features/userscopy'
import { roles } from '@/features/userscopy/data/data'

const usersSearchSchema = z.object({
  page: z.number().optional().catch(1),
  pageSize: z.number().optional().catch(10),
  // Facet filters
  status: z
    .array(z.union([z.literal('ativo'), z.literal('inativo')]))
    .optional()
    .catch([]),
  role: z
    .array(z.enum(roles.map((r) => r.value as (typeof roles)[number]['value'])))
    .optional()
    .catch([]),
  // Filtro de texto por nome
  name: z.string().optional().catch(''),
})

export const Route = createFileRoute('/_authenticated/userscopy/')({
  validateSearch: usersSearchSchema,
  component: Users,
})
