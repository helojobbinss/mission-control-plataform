import { AxiosError } from 'axios'
import { createFileRoute, redirect } from '@tanstack/react-router'
import { useAuthStore } from '@/stores/auth-store'
import { AuthenticatedLayout } from '@/components/layout/authenticated-layout'
import { fetchCurrentUser } from '@/features/auth/api'

export const Route = createFileRoute('/_authenticated')({
  // Só entra quem tem token. Se o usuário ainda não foi carregado
  // (ex.: recarregou a página), busca em GET /api/user.
  beforeLoad: async ({ location }) => {
    const { auth } = useAuthStore.getState()
    const toSignIn = () =>
      redirect({ to: '/sign-in', search: { redirect: location.href } })

    if (!auth.accessToken) throw toSignIn()

    if (!auth.user) {
      try {
        auth.setUser(await fetchCurrentUser())
      } catch (error) {
        if (error instanceof AxiosError && error.response?.status === 401) {
          auth.reset()
          throw toSignIn()
        }
        // Backend fora do ar: segue para a página; as chamadas mostram o erro.
      }
    }
  },
  component: AuthenticatedLayout,
})
