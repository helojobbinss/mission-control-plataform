<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    /**
     * Lista os usuários cadastrados (somente gerente).
     */
    public function index(Request $request)
    {
        if (!$this->isManager($request)) {
            return $this->forbidden('Você não tem permissão para listar usuários.');
        }

        $users = User::with('role')
            ->orderBy('name')
            ->get()
            ->map(function (User $user) {
                return $this->present($user);
            });

        return response()->json(['users' => $users]);
    }

    /**
     * Lista os papéis disponíveis, para o formulário de cadastro.
     */
    public function roles()
    {
        $roles = Role::orderBy('id')->get(['id', 'name', 'description']);

        return response()->json(['roles' => $roles]);
    }

    /**
     * Cadastra um novo usuário (somente gerente).
     */
    public function store(Request $request)
    {
        if (!$this->isManager($request)) {
            return $this->forbidden('Você não tem permissão para cadastrar usuários.');
        }

        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => [
                'required',
                'email',
                'max:255',
                'unique:users,email',
            ],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'role_id' => [
                'required',
                'integer',
                Rule::exists('roles', 'id'),
            ],
        ], [
            'name.required' => 'Informe o nome.',
            'email.required' => 'Informe o e-mail.',
            'email.email' => 'Informe um e-mail válido.',
            'email.unique' => 'Este e-mail já está cadastrado.',
            'password.required' => 'Informe a senha.',
            'password.min' => 'A senha precisa ter pelo menos 8 caracteres.',
            'password.confirmed' => 'As senhas não coincidem.',
            'role_id.required' => 'Selecione um papel.',
            'role_id.exists' => 'Papel inválido.',
        ]);

        $user = User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
            'role_id' => $data['role_id'],
            'is_active' => true,
        ]);

        return response()->json([
            'message' => 'Usuário criado com sucesso.',
            'user' => $this->present($user->load('role')),
        ], 201);
    }

    private function isManager(Request $request): bool
    {
        $role = $request->user()->role;

        return $role && $role->name === 'gerente';
    }

    private function forbidden(string $message)
    {
        return response()->json(['message' => $message], 403);
    }

    private function present(User $user): array
    {
        return [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'role' => $user->role ? $user->role->name : null,
            'is_active' => (bool) $user->is_active,
            'created_at' => optional($user->created_at)->toIso8601String(),
        ];
    }
}
