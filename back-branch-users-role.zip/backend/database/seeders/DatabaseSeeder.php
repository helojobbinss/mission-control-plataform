<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Popula o banco: papéis (gerente, operador, analista_dados)
     * e o primeiro usuário gerente.
     *
     * Rodar com: php artisan migrate --seed
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            RoleSeeder::class,
            AdminUserSeeder::class,
        ]);
    }
}
