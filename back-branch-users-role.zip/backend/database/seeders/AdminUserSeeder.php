<?php

namespace Database\Seeders;

use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

/**
 * Cria o primeiro usuário gerente, para que alguém consiga entrar no
 * sistema e cadastrar os demais (POST /api/users exige um gerente).
 *
 * E-mail e senha vêm do .env (ADMIN_EMAIL / ADMIN_PASSWORD).
 * Troque a senha padrão em qualquer ambiente que não seja o seu local.
 */
class AdminUserSeeder extends Seeder
{
    public function run()
    {
        $gerente = Role::where('name', 'gerente')->firstOrFail();

        User::firstOrCreate(
            ['email' => env('ADMIN_EMAIL', 'admin@missioncontrol.local')],
            [
                'name' => env('ADMIN_NAME', 'Administrador'),
                'password' => Hash::make(env('ADMIN_PASSWORD', 'Admin@1234')),
                'role_id' => $gerente->id,
                'is_active' => true,
            ]
        );
    }
}
