<?php

namespace Tests\Feature;

use App\Models\Role;
use App\Models\User;
use Database\Seeders\DatabaseSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class UserApiTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(DatabaseSeeder::class);
    }

    private function loginAsAdmin(): string
    {
        return $this->postJson('/api/login', [
            'email' => 'admin@missioncontrol.local',
            'password' => 'Admin@1234',
        ])->assertOk()->json('token');
    }

    public function test_seeder_cria_gerente_que_consegue_logar()
    {
        $this->postJson('/api/login', [
            'email' => 'admin@missioncontrol.local',
            'password' => 'Admin@1234',
        ])
            ->assertOk()
            ->assertJsonPath('user.role', 'gerente')
            ->assertJsonStructure(['token', 'token_type', 'user' => ['id', 'name', 'email', 'role']]);
    }

    public function test_login_com_senha_errada_retorna_422()
    {
        $this->postJson('/api/login', [
            'email' => 'admin@missioncontrol.local',
            'password' => 'errada',
        ])->assertStatus(422)->assertJsonValidationErrors('email');
    }

    public function test_gerente_lista_papeis_e_usuarios()
    {
        $token = $this->loginAsAdmin();

        $this->withToken($token)->getJson('/api/roles')
            ->assertOk()
            ->assertJsonCount(3, 'roles');

        $this->withToken($token)->getJson('/api/users')
            ->assertOk()
            ->assertJsonPath('users.0.email', 'admin@missioncontrol.local');
    }

    public function test_gerente_cria_usuario_que_depois_consegue_logar()
    {
        $token = $this->loginAsAdmin();
        $operador = Role::where('name', 'operador')->first();

        $this->withToken($token)->postJson('/api/users', [
            'name' => 'Maria Operadora',
            'email' => 'maria@missioncontrol.local',
            'password' => 'Senha@123',
            'password_confirmation' => 'Senha@123',
            'role_id' => $operador->id,
        ])
            ->assertCreated()
            ->assertJsonPath('user.role', 'operador')
            ->assertJsonPath('user.is_active', true);

        $this->postJson('/api/login', [
            'email' => 'maria@missioncontrol.local',
            'password' => 'Senha@123',
        ])->assertOk()->assertJsonPath('user.role', 'operador');
    }

    public function test_email_duplicado_retorna_mensagem_em_portugues()
    {
        $token = $this->loginAsAdmin();

        $this->withToken($token)->postJson('/api/users', [
            'name' => 'Outro',
            'email' => 'admin@missioncontrol.local',
            'password' => 'Senha@123',
            'password_confirmation' => 'Senha@123',
            'role_id' => Role::where('name', 'operador')->value('id'),
        ])
            ->assertStatus(422)
            ->assertJsonPath('errors.email.0', 'Este e-mail já está cadastrado.');
    }

    public function test_operador_nao_pode_listar_nem_criar_usuarios()
    {
        $operador = Role::where('name', 'operador')->first();
        User::create([
            'name' => 'Op',
            'email' => 'op@missioncontrol.local',
            'password' => Hash::make('Senha@123'),
            'role_id' => $operador->id,
            'is_active' => true,
        ]);
        $token = $this->postJson('/api/login', [
            'email' => 'op@missioncontrol.local',
            'password' => 'Senha@123',
        ])->json('token');

        $this->withToken($token)->getJson('/api/users')->assertForbidden();
        $this->withToken($token)->postJson('/api/users', [])->assertForbidden();
    }

    public function test_rotas_protegidas_exigem_token()
    {
        $this->getJson('/api/users')->assertUnauthorized();
        $this->getJson('/api/user')->assertUnauthorized();
    }
}
